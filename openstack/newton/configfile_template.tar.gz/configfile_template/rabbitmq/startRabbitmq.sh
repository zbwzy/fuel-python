#!/bin/bash

rabbitmq-plugins enable rabbitmq_management

systemctl start rabbitmq-server

