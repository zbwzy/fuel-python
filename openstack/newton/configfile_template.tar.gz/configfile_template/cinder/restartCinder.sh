#!/bin/bash


systemctl restart openstack-cinder-api.service
systemctl restart openstack-cinder-scheduler.service

