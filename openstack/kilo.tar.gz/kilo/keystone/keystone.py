'''
Created on Aug 26, 2015

@author: zhangbai
'''

'''
usage:

python keystone.py

NOTE: the params is from conf/openstack_params.json, this file is initialized when user drives FUEL to install env.
'''
import sys
import os
import time

reload(sys)
sys.setdefaultencoding('utf8')

debug = False

if debug == True :
    #MODIFY HERE WHEN TEST ON HOST
    PROJ_HOME_DIR = '/Users/zhangbai/Documents/AptanaWorkspace/fuel-python'
    pass
else :
    # The real dir in which this project is deployed on PROD env.
    PROJ_HOME_DIR = '/etc/puppet/fuel-python'   
    pass

OPENSTACK_VERSION_TAG = 'kilo'
OPENSTACK_CONF_FILE_TEMPLATE_DIR = os.path.join(PROJ_HOME_DIR, 'openstack', OPENSTACK_VERSION_TAG, 'configfile_template')
SOURCE_KEYSTONE_CONF_FILE_TEMPLATE_PATH = os.path.join(OPENSTACK_CONF_FILE_TEMPLATE_DIR, 'keystone', 'keystone.conf')

sys.path.append(PROJ_HOME_DIR)


from common.shell.ShellCmdExecutor import ShellCmdExecutor
from common.json.JSONUtil import JSONUtility
from common.properties.PropertiesUtil import PropertiesUtility
from common.file.FileUtil import FileUtil
from common.yaml.YAMLUtil import YAMLUtil
from openstack.common.serverSequence import ServerSequence
from openstack.kilo.ssh.SSH import SSH

class Prerequisites(object):
    '''
    classdocs
    '''
    def __init__(self):
        '''
        Constructor
        '''
        pass
    
    @staticmethod
    def prepare():
        Network.Prepare()
        
        cmd = 'yum install openstack-utils -y'
        ShellCmdExecutor.execCmd(cmd)
        
        cmd = 'yum install openstack-selinux -y'
        ShellCmdExecutor.execCmd(cmd)
        
        cmd = 'yum install python-openstackclient -y'
        ShellCmdExecutor.execCmd(cmd)
        pass
    pass

class Network(object):
    '''
    classdocs
    '''
    def __init__(self):
        '''
        Constructor
        '''
        pass
    
    @staticmethod
    def Prepare():
        Network.stopIPTables()
        Network.stopNetworkManager()
        pass
    
    @staticmethod
    def stopIPTables():
        stopCmd = "service iptables stop"
        ShellCmdExecutor.execCmd(stopCmd)
        pass
    
    @staticmethod
    def stopNetworkManager():
        stopCmd = "service NetworkManager stop"
        chkconfigOffCmd = "chkconfig NetworkManager off"
        
        ShellCmdExecutor.execCmd(stopCmd)
        ShellCmdExecutor.execCmd(chkconfigOffCmd)
        pass

class Keystone(object):
    '''
    classdocs
    '''
    
    def __init__(self):
        '''
        Constructor
        '''
        pass
    
    @staticmethod
    def install():
        print 'Keystone node install start========'
        #Enable 
        if debug == True:
            print 'DEBUG is True.On local dev env, do test====='
            yumCmd = "ls -lt"
        else :
            yumCmd = "yum install openstack-keystone httpd mod_wsgi python-openstackclient python-memcached -y"
            
        ShellCmdExecutor.execCmd(yumCmd)
#         Keystone.configConfFile()
#         Keystone.start()
        
        print 'Keystone node install done####'
        pass
    
    @staticmethod
    def start():
        print "start keystone========="
        #assign rights
        ShellCmdExecutor.execCmd('chown -R keystone:keystone /etc/keystone')
#         ShellCmdExecutor.execCmd('chown -R keystone:keystone /var/www/cgi-bin/keystone')
#         ShellCmdExecutor.execCmd('chmod 755 /var/www/cgi-bin/keystone/*')
        if debug == True :
            print 'DEBUG=True.On local dev env, do test===='
            pass
        else :
            Keystone.startHttp()
            pass
        print "start keystone done####"
        pass
    
    @staticmethod
    def restart():
        print "restart keystone========="
        if debug == True :
            print 'DEBUG=True.On local dev env, do test===='
            pass
        else :
            ShellCmdExecutor.execCmd('service openstack-keystone restart')
            pass
        
        print "restart keystone done####"
        pass
    
    @staticmethod
    def importKeystoneDBSchema():
        #Before import,detect the database rights for mysql user keystone.
        ##
        importCmd = 'su -s /bin/sh -c "keystone-manage db_sync" keystone'
        ShellCmdExecutor.execCmd(importCmd)
        pass
    
    @staticmethod
    def supportPKIToken():
        cmd0 = 'keystone-manage pki_setup --keystone-user keystone --keystone-group keystone'
        ShellCmdExecutor.execCmd(cmd0)
        
        if not os.path.exists('/var/log/keystone') :
            os.system('mkdir -p /var/log/keystone')
            pass
        
        if not os.path.exists('/etc/keystone/ssl') :
            os.system('mkdir -p /etc/keystone/ssl')
            pass
        
        cmd1 = 'chown -R keystone:keystone /var/log/keystone'
        cmd2 = 'chown -R keystone:keystone /etc/keystone/ssl'
        cmd3 = 'chmod -R o-rwx /etc/keystone/ssl'
        ShellCmdExecutor.execCmd(cmd1)
        ShellCmdExecutor.execCmd(cmd2)
        ShellCmdExecutor.execCmd(cmd3)
        pass
    
    @staticmethod
    def supportFernet():
        cmd0 = 'keystone-manage fernet_setup --keystone-user keystone --keystone-group keystone'
        ShellCmdExecutor.execCmd(cmd0)
        
        cmd1 = 'keystone-manage credential_setup --keystone-user keystone --keystone-group keystone'
        ShellCmdExecutor.execCmd(cmd1)
        
        if not os.path.exists('/var/log/keystone') :
            os.system('mkdir -p /var/log/keystone')
            pass
        
        if not os.path.exists('/etc/keystone/fernet-keys') :
            os.system('mkdir -p /etc/keystone/fernet-keys')
            pass
        
        cmd1 = 'chown -R keystone:keystone /var/log/keystone'
        cmd2 = 'chown -R keystone:keystone /etc/keystone/fernet-keys'
        cmd3 = 'chmod -R o-rwx /etc/keystone/fernet-keys'
        ShellCmdExecutor.execCmd(cmd1)
        ShellCmdExecutor.execCmd(cmd2)
        ShellCmdExecutor.execCmd(cmd3)
        pass
    
    @staticmethod
    def bootstrapIdentityService():
        bootsrap_cmd_template = 'keystone-manage bootstrap --bootstrap-password {keystone_admin_password} --bootstrap-admin-url http://{keystone_vip}:35357/v3/ --bootstrap-internal-url http://{keystone_vip}:35357/v3/ --bootstrap-public-url http://{keystone_vip}:5000/v3/ --bootstrap-region-id RegionOne'
        
        
        vipParamsDict = JSONUtility.getValue('vip')
        keystone_admin_password = JSONUtility.getValue('keystone_admin_password')
        keystone_vip = vipParamsDict['keystone_vip']
        cmd = bootsrap_cmd_template.format(keystone_admin_password=keystone_admin_password,keystone_vip=keystone_vip)
        print 'bootsrap identity service cmd=%s--' % cmd
        ShellCmdExecutor.execCmd(cmd)
        pass
    
    @staticmethod
    def httpConf():
        wsgi_keystone_conf_file_path = os.path.join(OPENSTACK_CONF_FILE_TEMPLATE_DIR, 'keystone', 'wsgi-keystone.conf')
        ShellCmdExecutor.execCmd('cp -r %s /etc/httpd/conf.d/' % wsgi_keystone_conf_file_path)
        
        httpd_conf_file_path = os.path.join(OPENSTACK_CONF_FILE_TEMPLATE_DIR, 'keystone', 'httpd.conf')
        ShellCmdExecutor.execCmd('cp -r %s /etc/httpd/conf/' % httpd_conf_file_path)
        
        localIP = YAMLUtil.getManagementIP()
        FileUtil.replaceFileContent('/etc/httpd/conf.d/wsgi-keystone.conf', '<LOCAL_IP>', localIP)
        FileUtil.replaceFileContent('/etc/httpd/conf/httpd.conf', '<LOCAL_IP>', localIP)
        
        ShellCmdExecutor.execCmd('ln -s /usr/share/keystone/wsgi-keystone.conf /etc/httpd/conf.d/')
        pass
    
    @staticmethod
    def startHttp():
        ShellCmdExecutor.execCmd('systemctl enable httpd.service')
        ShellCmdExecutor.execCmd('systemctl start httpd.service')
        pass
    
    @staticmethod
    def installWSGI():
        ShellCmdExecutor.execCmd('mkdir -p /var/www/cgi-bin/keystone')
        main_python_file_path = os.path.join(OPENSTACK_CONF_FILE_TEMPLATE_DIR, 'keystone', 'main')
        ShellCmdExecutor.execCmd('cp -r %s /var/www/cgi-bin/keystone' % main_python_file_path)
        ShellCmdExecutor.execCmd('cp /var/www/cgi-bin/keystone/main /var/www/cgi-bin/keystone/admin')
        ShellCmdExecutor.execCmd('chown -R keystone:keystone /var/www/cgi-bin/keystone')
        ShellCmdExecutor.execCmd('chmod 755 /var/www/cgi-bin/keystone/*')
        pass
  
    
    @staticmethod
    def configureEnvVar():
        ShellCmdExecutor.execCmd('export OS_SERVICE_TOKEN=123456')
        template_string = 'export OS_SERVICE_ENDPOINT=http://<KEYSTONE_VIP>:35357/v2.0'
        vipParamsDict = JSONUtility.getValue('vip')
        keystone_vip = vipParamsDict["keystone_vip"]
        cmd = template_string.replace('<KEYSTONE_VIP>', keystone_vip)
        ShellCmdExecutor.execCmd(cmd)
        pass
    
    @staticmethod
    def initKeystone():
        keystoneInitScriptPath = os.path.join(OPENSTACK_CONF_FILE_TEMPLATE_DIR, 'keystone', 'keystone_init.sh')
        print 'keystoneInitScriptPath=%s' % keystoneInitScriptPath
        
        if os.path.exists('/opt/keystone_init.sh') :
            ShellCmdExecutor.execCmd('sudo rm -rf /opt/keystone_init.sh')
            pass
        
        ShellCmdExecutor.execCmd('cp -r %s /opt/' % keystoneInitScriptPath)
        
        localIP = YAMLUtil.getManagementIP()
        FileUtil.replaceFileContent('/opt/keystone_init.sh', '<LOCAL_IP>', localIP)
        
        keystoneAdminEmail = JSONUtility.getValue("admin_email")
        FileUtil.replaceFileContent('/opt/keystone_init.sh', '<ADMIN_EMAIL>', keystoneAdminEmail)
        
        vipParamsDict = JSONUtility.getValue('vip')
        keystone_vip = vipParamsDict["keystone_vip"]
        FileUtil.replaceFileContent('/opt/keystone_init.sh', '<KEYSTONE_VIP>', keystone_vip)
        ShellCmdExecutor.execCmd('bash /opt/keystone_init.sh')
        pass
        
    @staticmethod
    def sourceAdminOpenRC():
        adminOpenRCScriptPath = os.path.join(OPENSTACK_CONF_FILE_TEMPLATE_DIR, 'admin_openrc.sh')
        print 'adminOpenRCScriptPath=%s' % adminOpenRCScriptPath
        
        ShellCmdExecutor.execCmd('cp -r %s /opt/' % adminOpenRCScriptPath)
        
        vipParamsDict = JSONUtility.getValue('vip')
        keystone_vip = vipParamsDict["keystone_vip"]
        FileUtil.replaceFileContent('/opt/admin_openrc.sh', '<KEYSTONE_VIP>', keystone_vip)
        time.sleep(2)
        ShellCmdExecutor.execCmd('source /opt/admin_openrc.sh')
        pass
    
    @staticmethod
    def configConfFile():
        print "configure keystone conf file======"
        vipParamsDict = JSONUtility.getValue('vip')
        mysql_vip = vipParamsDict["mysql_vip"]
        keystone_vip = vipParamsDict['keystone_vip']
 
        #memcache service list
        keystone_params_dict = JSONUtility.getRoleParamsDict('keystone')
        keystone_ip_list = keystone_params_dict['mgmt_ips']
        memcached_service_list = []
        for ip in keystone_ip_list:
            memcached_service_list.append(ip.strip() + ':11211')
            pass
        
        memcached_service_string = ','.join(memcached_service_list)
        print 'memcached_service_string=%s--' % memcached_service_string
        
        openstackConfPopertiesFilePath = PropertiesUtility.getOpenstackConfPropertiesFilePath()
        keystoneConfDir = PropertiesUtility.getValue(openstackConfPopertiesFilePath, 'KEYSTONE_CONF_DIR')
        
        keystone_conf_file_path = os.path.join(keystoneConfDir, 'keystone.conf')
        
        if not os.path.exists(keystoneConfDir) :
            os.system("sudo mkdir -p %s" % keystoneConfDir)
            pass
        
        ShellCmdExecutor.execCmd("cp -r %s %s" % (SOURCE_KEYSTONE_CONF_FILE_TEMPLATE_PATH, keystoneConfDir))
        ShellCmdExecutor.execCmd("sudo chmod 777 %s" % keystone_conf_file_path)
#         #if exist, remove original conf files
#         if os.path.exists(keystone_conf_file_path) :
#             os.system("sudo rm -rf %s" % keystone_conf_file_path)
#             pass
#         
#         ShellCmdExecutor.execCmd('chmod 777 /etc/keystone')
#         
# #         os.system("sudo cp -r %s %s" % (SOURCE_KEYSTONE_CONF_FILE_TEMPLATE_PATH, keystoneConfDir))
#         ###NEW
#         ShellCmdExecutor.execCmd('cat %s > /tmp/keystone.conf' % SOURCE_KEYSTONE_CONF_FILE_TEMPLATE_PATH)
#         ShellCmdExecutor.execCmd('mv /tmp/keystone.conf /etc/keystone/')
#         
#         ShellCmdExecutor.execCmd("sudo chmod 777 %s" % keystone_conf_file_path)
        ###########LOCAL_IP:retrieve it from one file, the LOCAL_IP file is generated when this project inits.
        localIP = YAMLUtil.getManagementIP()  
        
#         FileUtil.replaceByRegularExpression(keystone_conf_file_path, '<LOCAL_IP>', localIP)
#         FileUtil.replaceByRegularExpression(keystone_conf_file_path, '<MYSQL_VIP>', mysql_vip)
        keystoneDbPass = JSONUtility.getValue('keystone_dbpass')
#         FileUtil.replaceFileContent(keystone_conf_file_path, '<ADMIN_TOKEN>', admin_token)
        FileUtil.replaceFileContent(keystone_conf_file_path, '<LOCAL_MANAGEMENT_IP>', localIP)
        FileUtil.replaceFileContent(keystone_conf_file_path, '<MYSQL_VIP>', mysql_vip)
        FileUtil.replaceFileContent(keystone_conf_file_path, '<MEMCACHED_LIST>', memcached_service_string)
        FileUtil.replaceFileContent(keystone_conf_file_path,'<KEYSTONE_DBPASS>', keystoneDbPass)
        
        ShellCmdExecutor.execCmd("chmod 644 %s" % keystone_conf_file_path)
        
        print "configure keystone conf file done####"
        pass
    
    @staticmethod
    def getServerIndex():
        local_management_ip = YAMLUtil.getManagementIP() 
        keystone_params_dict = JSONUtility.getRoleParamsDict('keystone')
        keystone_ip_list = keystone_params_dict['mgmt_ips']
        index = ServerSequence.getIndex(keystone_ip_list, local_management_ip)
        return index
    
    @staticmethod
    def getLaunchedRDBServersNum():
        cmd = 'ls -lt /opt/openstack_conf/tag/ | grep bcrdb_ | wc -l' 
        output, exitcode = ShellCmdExecutor.execCmd(cmd)
        launchedRdbNum = output.strip()
        return launchedRdbNum
    
    @staticmethod
    def scpSSL():
        '''
        # scp -r root@{keystone_0_ip}:/etc/keystone/ssl /etc/keystone/
        # chown -R keystone:keystone /etc/keystone/
        '''
        keystone_params_dict = JSONUtility.getRoleParamsDict('keystone')
        keystone_ip_list = keystone_params_dict['mgmt_ips']
        
        #scp ssl from first keystone
        scpCmd = 'scp -r root@{keystone_0_ip}:/etc/keystone/ssl /etc/keystone/'.format(keystone_0_ip=keystone_ip_list[0])
        try:
            import pexpect
            #To make the interact string: Are you sure you want to continue connecting.* always appear
            if os.path.exists('/root/.ssh/known_hosts') :
                os.system('rm -rf /root/.ssh/known_hosts')
                pass
    
            child = pexpect.spawn(scpCmd)
            
            #When do the first shell cmd execution, this interact message is appeared on shell.
            child.expect('Are you sure you want to continue connecting.*')
            child.sendline('yes')
    
            while True :
                regex = "[\\s\\S]*" #match any
                index = child.expect([regex , pexpect.EOF, pexpect.TIMEOUT])
                if index == 0:
                    break
                elif index == 1:
                    pass   #continue to wait
                elif index == 2:
                    pass   #continue to wait
    
            child.sendline('exit')
            child.sendcontrol('c')
            #child.interact()
        except OSError:
            print 'Catch exception %s when send tag.' % OSError.strerror
            sys.exit(0)
            pass
        pass
    
    @staticmethod
    def scpFernetKeys():
        '''
        # scp -r root@{keystone_0_ip}:/etc/keystone/fernet-keys /etc/keystone/
        # chown -R keystone:keystone /etc/keystone/
        '''
        keystone_params_dict = JSONUtility.getRoleParamsDict('keystone')
        keystone_ip_list = keystone_params_dict['mgmt_ips']
        
        #scp fernet-keys from first keystone
        scpCmd = 'scp -r root@{keystone_0_ip}:/etc/keystone/fernet-keys /etc/keystone/'.format(keystone_0_ip=keystone_ip_list[0])
        try:
            import pexpect
            #To make the interact string: Are you sure you want to continue connecting.* always appear
            if os.path.exists('/root/.ssh/known_hosts') :
                os.system('rm -rf /root/.ssh/known_hosts')
                pass
    
            child = pexpect.spawn(scpCmd)
            
            #When do the first shell cmd execution, this interact message is appeared on shell.
            child.expect('Are you sure you want to continue connecting.*')
            child.sendline('yes')
    
            while True :
                regex = "[\\s\\S]*" #match any
                index = child.expect([regex , pexpect.EOF, pexpect.TIMEOUT])
                if index == 0:
                    break
                elif index == 1:
                    pass   #continue to wait
                elif index == 2:
                    pass   #continue to wait
    
            child.sendline('exit')
            child.sendcontrol('c')
            #child.interact()
        except OSError:
            print 'Catch exception %s when send tag.' % OSError.strerror
            sys.exit(0)
            pass
        pass
    

if __name__ == '__main__':
    
    print 'hello openstack-kilo:keystone============'
    print 'start time: %s' % time.ctime()
    #when execute script,exec: python <this file absolute path>
    #The params are retrieved from conf/openstack_params.json: generated in init.pp in site.pp.
    ###############################
    INSTALL_TAG_FILE = '/opt/openstack_conf/tag/install/keystone_installed'
    
    if os.path.exists(INSTALL_TAG_FILE) :
        print 'keystone installed####'
        print 'exit===='
        pass
    else :
        print 'start to install======='
#         Prerequisites.prepare()
        Keystone.install()
        Keystone.configConfFile()
        
        keystone_params_dict = JSONUtility.getRoleParamsDict('keystone')
        keystone_ip_list = keystone_params_dict['mgmt_ips']
        
        if Keystone.getServerIndex() == 0 :
            Keystone.supportFernet()
            
            if len(keystone_ip_list) > 1 :
                from openstack.kilo.ssh.SSH import SSH
                #Mark /etc/keystone/fernet-keys produced on first keystone
                tag_file_name = 'keystone_0_fernet'
                for keystone_ip in keystone_ip_list[1:] :
                    SSH.sendTagTo(keystone_ip, tag_file_name)
                    pass
                pass
            
            Keystone.bootstrapIdentityService()
            
            #bootstrap the identity service
            
            pass
        else :
            ##scp /etc/keystone/fernet-keys from first keystone.
            pass
        
        ####only when rdb cluster is prepared, then import keystone db schema.
        
        Keystone.httpConf()
        
#         Keystone.installWSGI()
        
        from openstack.kilo.common.adminopenrc import AdminOpenrc
        AdminOpenrc.prepareAdminOpenrc()
        #mark: keystone is installed
        os.system('touch %s' % INSTALL_TAG_FILE)
    print 'hello openstack-kilo:keystone#######'
    pass

