#!/bin/bash

#add user bcrdb
useradd bcrdb
#assign rights
chown -R bcrdb:bcrdb /opt/bcrdb